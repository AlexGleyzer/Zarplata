# Інструкція з Встановлення та Запуску

## 📦 Що ви отримали

Повний проект системи управління розрахунками зарплати:

```
zarplata/
├── backend/                 # Python FastAPI + PostgreSQL
├── frontend/                # React інтерфейс
├── docker-compose.yml       # Конфігурація Docker
├── .env.example            # Приклад налаштувань
├── .gitignore              # Git ignore правила
├── README.md               # Документація
├── start.bat               # Швидкий запуск (Windows)
└── payroll_system_architecture.md  # Повна архітектура
```

## 🚀 Швидкий Запуск (3 кроки)

### Крок 1: Копіювання файлів

Скопіюйте всі завантажені файли в папку `C:\Work\zarplata\`

### Крок 2: Запуск Docker Desktop

Переконайтеся що Docker Desktop запущено на вашому комп'ютері.

### Крок 3: Запуск проекту

**Найпростіший спосіб:**
```bash
start.bat
```

Скрипт автоматично:
- Перевірить Docker
- Створить .env файл
- Запустить всі сервіси
- Відкриє браузер

**Або вручну:**
```bash
# Створити .env
copy .env.example .env

# Запустити Docker Compose
docker-compose up -d

# Почекати 30 секунд поки все стартує
```

## 📍 Адреси Сервісів

Після запуску доступні:

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8000
- **API Documentation**: http://localhost:8000/docs
- **PostgreSQL**: localhost:5432 (admin/secure_password)

## ✅ Перевірка Роботи

### 1. Перевірте що контейнери запущені:
```bash
docker-compose ps
```

Повинні бачити 3 запущені сервіси:
- payroll_postgres
- payroll_backend
- payroll_frontend

### 2. Перевірте Backend:
Відкрийте http://localhost:8000/health

Повинні побачити:
```json
{"status": "healthy"}
```

### 3. Перевірте Frontend:
Відкрийте http://localhost:3000

Повинні побачити інтерфейс системи.

### 4. Перевірте тестові дані:
У вкладці "Працівники" повинні бачити 10 працівників.

## 🎯 Перший Тест

1. Відкрийте http://localhost:3000
2. На головній сторінці введіть:
   ```
   створити період січень
   ```
3. Натисніть "Виконати"
4. Перейдіть на вкладку "Періоди"
5. Повинні побачити створений період

## 📊 Що Є в Системі (Тестові Дані)

- ✅ 10 працівників
- ✅ 12 організаційних підрозділів  
- ✅ 3 правила розрахунків (зарплата, ПДФО, військовий збір)
- ✅ 1 шаблон розрахунку
- ✅ Всі таблиці БД створені

## 🛠 Корисні Команди

### Перегляд логів:
```bash
# Всі сервіси
docker-compose logs -f

# Тільки backend
docker-compose logs -f backend

# Тільки база даних
docker-compose logs -f postgres
```

### Перезапуск:
```bash
docker-compose restart
```

### Зупинка:
```bash
docker-compose down
```

### Повне очищення (з даними):
```bash
docker-compose down -v
```

### Підключення до БД:
```bash
docker exec -it payroll_postgres psql -U admin -d payroll
```

## 🔧 Розробка

### Backend (без Docker):

```bash
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

### Frontend (без Docker):

```bash
cd frontend
npm install
npm start
```

## ❗ Troubleshooting

### Порт зайнятий

Якщо порт 5432, 8000 або 3000 зайнятий:

Відредагуйте `docker-compose.yml`:
```yaml
ports:
  - "5433:5432"  # PostgreSQL
  - "8001:8000"  # Backend
  - "3001:3000"  # Frontend
```

### Docker не запускається

1. Перевірте що Docker Desktop запущено
2. Перезапустіть Docker Desktop
3. Перевірте налаштування WSL2 (для Windows)

### Backend не підключається до БД

```bash
# Перевірте що PostgreSQL запущено
docker ps | grep postgres

# Подивіться логи
docker logs payroll_postgres

# Перезапустіть сервіс
docker-compose restart postgres
docker-compose restart backend
```

### Frontend показує помилку підключення

1. Перевірте що backend працює: http://localhost:8000/health
2. Перевірте в браузері Console (F12) чи немає CORS помилок
3. Перезапустіть frontend: `docker-compose restart frontend`

## 📚 Наступні Кроки

1. **Вивчіть архітектуру**: `payroll_system_architecture.md`
2. **Подивіться API**: http://localhost:8000/docs
3. **Спробуйте створити період** через UI
4. **Запустіть перший розрахунок**

## 💡 Додаткова Інформація

- Всі дані зберігаються в Docker volume `postgres_data`
- Backend автоматично створює таблиці при запуску (Alembic migrations)
- Frontend працює в development режимі з hot-reload
- Тестові дані завантажуються автоматично

## 🆘 Потрібна Допомога?

1. Перевірте README.md для детальної документації
2. Подивіться API документацію: http://localhost:8000/docs
3. Перевірте логи: `docker-compose logs -f`

---

**Готово! Система запущена та готова до роботи! 🎉**
