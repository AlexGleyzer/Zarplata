# Payroll Management System / Система Управління Розрахунками Зарплати

Комплексна система для управління розрахунками заробітної плати з підтримкою складних правил, workflow затвердження та історії змін.

## 🚀 Швидкий старт

### Передумови

- Docker Desktop встановлено і запущено
- Git
- Node.js 18+ (для frontend розробки)
- Python 3.11+ (для backend розробки)

### Встановлення

1. **Клонуйте репозиторій** (або використайте існуючу папку):
```bash
cd C:\Work\zarplata
```

2. **Створіть .env файл** з налаштуваннями:
```bash
copy .env.example .env
```

3. **Запустіть всю систему через Docker**:
```bash
docker-compose up -d
```

Це запустить:
- PostgreSQL на порту 5432
- Backend API на порту 8000
- Frontend на порту 3000

4. **Перевірте що все працює**:
- Backend API: http://localhost:8000
- Frontend: http://localhost:3000
- API Docs: http://localhost:8000/docs

### Перший запуск - Створення таблиць

При першому запуску автоматично виконаються:
1. Міграції Alembic (створення всіх таблиць)
2. Seed тестових даних

Щоб перевірити структуру БД:
```bash
docker exec -it payroll_postgres psql -U admin -d payroll -c "\dt"
```

## 📁 Структура Проекту

```
zarplata/
├── backend/                    # FastAPI Backend
│   ├── alembic/               # Database migrations
│   │   ├── versions/          # Migration files
│   │   ├── env.py
│   │   └── script.py.mako
│   ├── app/
│   │   ├── api/               # API endpoints
│   │   │   ├── endpoints/
│   │   │   └── __init__.py
│   │   ├── core/              # Core configuration
│   │   │   ├── config.py
│   │   │   └── database.py
│   │   ├── models/            # SQLAlchemy models
│   │   │   ├── module1.py     # Структура і працівники
│   │   │   ├── module2.py     # Результати роботи
│   │   │   ├── module3.py     # Періоди і нарахування
│   │   │   ├── module4.py     # Платежі
│   │   │   └── __init__.py
│   │   ├── schemas/           # Pydantic schemas
│   │   ├── services/          # Business logic
│   │   └── main.py            # FastAPI app
│   ├── alembic.ini
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/                   # React Frontend
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── services/
│   │   └── App.jsx
│   ├── package.json
│   └── Dockerfile
├── database/                   # Database initialization
│   └── init/
├── docker-compose.yml
├── .env
├── .env.example
├── .gitignore
├── payroll_system_architecture.md
└── README.md
```

## 🗄️ Архітектура Бази Даних

Система складається з 4 модулів:

### Модуль 1: Структура Підприємства і Працівники
- `organizational_units` - Організаційна ієрархія (до 6 рівнів)
- `employees` - Працівники
- `contracts` - Контракти (salary, hourly, piecework, task_based)
- `calculation_rules` - Правила нарахувань з SQL кодом
- `calculation_templates` - Шаблони розрахунків
- `template_rules` - Зв'язок шаблонів і правил

### Модуль 2: Результати Роботи
- `work_results` - Загальна таблиця результатів
- `timesheets` - Табель обліку часу
- `production_results` - Виробництво

### Модуль 3: Періоди та Нарахування
- `calculation_periods` - Розрахункові періоди
- `accrual_documents` - Документи нарахувань
- `accrual_results` - Результати (immutable)
- `change_requests` - Запити на зміни

### Модуль 4: Платежі
- `payment_rules` - Правила формування платежів
- `payment_documents` - Документи платежів
- `payment_items` - Позиції платежів
- `bank_statements` - Банківські відомості

## 🔧 Розробка

### Backend

**Локальна розробка без Docker:**

```bash
cd backend

# Створити віртуальне середовище
python -m venv venv
venv\Scripts\activate

# Встановити залежності
pip install -r requirements.txt

# Запустити сервер
uvicorn app.main:app --reload
```

**Створення нової міграції:**

```bash
cd backend
alembic revision --autogenerate -m "Description of changes"
alembic upgrade head
```

**Відкат міграції:**

```bash
alembic downgrade -1
```

### Frontend

**Локальна розробка:**

```bash
cd frontend

# Встановити залежності
npm install

# Запустити dev server
npm start
```

## 📊 API Endpoints

### Працівники
- `GET /api/v1/employees` - Список працівників
- `POST /api/v1/employees` - Створити працівника
- `GET /api/v1/employees/{id}` - Деталі працівника

### Періоди
- `GET /api/v1/periods` - Список періодів
- `POST /api/v1/periods` - Створити період
- `GET /api/v1/periods/{id}` - Деталі періоду

### Розрахунки
- `POST /api/v1/calculations/run` - Запустити розрахунок
- `GET /api/v1/calculations/{id}` - Результати розрахунку

Повна документація: http://localhost:8000/docs

## 🎯 Ключові Принципи

### 1. Immutability (Незмінність)
- Дані ніколи не видаляються
- Зміни через створення нового документа + скасування старого
- Повна історія

### 2. Workflow
Документи мають статуси:
- `draft` - чернетка
- `in_review` - на розгляді
- `approved` - затверджено
- `cancelled` - скасовано

### 3. Ієрархія Правил
- Правила прив'язані до рівнів організаційної структури
- Успадкування від вищих рівнів до нижчих
- Можливість перевизначення на кожному рівні

### 4. Послідовне Виконання
- Правила в шаблоні виконуються по черзі
- Кожне правило бачить результати попередніх
- Порядок критичний

## 🔐 Безпека

- Всі SQL правила виконуються через prepared statements
- Параметри передаються окремо
- Валідація перед виконанням
- Аудит всіх операцій (created_by, updated_by)

## 📝 Тестові Дані

При першому запуску створюються:
- 10 працівників
- 12 організаційних підрозділів
- 3 правила розрахунків:
  - BASE_SALARY - Основна зарплата
  - PIT - ПДФО 18%
  - WAR_TAX - Військовий збір 1.5%
- 1 шаблон: MONTHLY_SALARY

## 🛠️ Корисні Команди

**Перезапуск всієї системи:**
```bash
docker-compose restart
```

**Перегляд логів:**
```bash
docker-compose logs -f backend
docker-compose logs -f postgres
```

**Зупинка системи:**
```bash
docker-compose down
```

**Повне очищення (включно з даними):**
```bash
docker-compose down -v
```

**Підключення до PostgreSQL:**
```bash
docker exec -it payroll_postgres psql -U admin -d payroll
```

## 📚 Додаткова Документація

- [Повна Архітектура](./payroll_system_architecture.md)
- [API Documentation](http://localhost:8000/docs)
- [ReDoc](http://localhost:8000/redoc)

## 🐛 Troubleshooting

**Порт 5432 зайнятий:**
```bash
# Змініть порт в docker-compose.yml
ports:
  - "5433:5432"  # Використайте інший порт
```

**Backend не підключається до БД:**
```bash
# Перевірте чи запущено PostgreSQL
docker ps | grep postgres

# Перевірте логи
docker logs payroll_postgres
```

**Frontend не бачить Backend:**
- Перевірте що Backend запущено: http://localhost:8000/health
- Перевірте REACT_APP_API_URL в .env

## 📄 Ліцензія

[Вкажіть ліцензію]

## 👥 Автори

[Ваше ім'я]
